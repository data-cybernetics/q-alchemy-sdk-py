# ruff: noqa: F401
from .enterjma import enter_jma
from .tool import Job

# Protocol version the JMA is using
__jma_version__ = [5, 0, 0]
