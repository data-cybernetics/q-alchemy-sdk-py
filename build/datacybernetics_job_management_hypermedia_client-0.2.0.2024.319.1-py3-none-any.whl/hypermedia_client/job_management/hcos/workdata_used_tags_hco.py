from typing import List, Self

import httpx

from hypermedia_client.core.hco.hco_base import Hco, Property
from hypermedia_client.core.hco.link_hco import LinkHco
from hypermedia_client.job_management.known_relations import Relations
from hypermedia_client.job_management.model.sirenentities import WorkDataUsedTagsEntity


class WorkDataUsedTagsHco(Hco[WorkDataUsedTagsEntity]):
    tags: List[str] | None = Property()

    self_link: 'WorkDataUsedTagsLink'

    @classmethod
    def from_entity(cls, entity: WorkDataUsedTagsEntity, client: httpx.Client) -> Self:
        instance = cls(client, entity)

        Hco.check_classes(instance._entity.class_, ["WorkDataUsedTags"])

        instance.self_link = WorkDataUsedTagsLink.from_entity(instance._client, instance._entity, Relations.SELF)

        return instance


class WorkDataUsedTagsLink(LinkHco):
    def navigate(self) -> WorkDataUsedTagsHco:
        return WorkDataUsedTagsHco.from_entity(self._navigate_internal(WorkDataUsedTagsEntity), self._client)

