class SirenException(Exception):
    pass
